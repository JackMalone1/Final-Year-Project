import gym


class GoExtraHardEnv(gym.Env):
    metadata = {'render.modes': ['human', 'terminal']}
