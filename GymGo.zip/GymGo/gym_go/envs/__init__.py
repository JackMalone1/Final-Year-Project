from gym_go.envs.go_env import GoEnv
from gym_go.envs.go_extrahard_env import GoExtraHardEnv
